<html>
	<head>
		<title>Autentificaci�n</title>
		<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-15">
		<style type = "text/css">
		</style>
	</head>
	<body background = "libroo.jpeg">
		<form action = 'admin.php' method = 'post'>
			Usuario : <input type = "name" name = "user" value = "--Escriba su Usuario--"/>
			Contrase�a : <input type = "password" name = "pass"/>
			<br />
			<br />
			<input type = "submit" value = "Aceptar"/>
		</form>
	</body>
</html> 
