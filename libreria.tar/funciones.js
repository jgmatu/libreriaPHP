	function nuevo()
	{
		var pagina = 'http://localhost/libreria/libro.php';
		document.location.href =pagina;
	}
	
	function volver()
	{
		var pagina = 'http://localhost/libreria/comprar.php';
		document.location.href = pagina;
	}
	
	function continuar()
	{
		var pagina = 'http://localhost/libreria/paso1add.php';
		document.location.href =pagina;
	}
	function imprimir()
	
		var pagina = 'http://localhost/libreria/imprimir.php';
		document.location.href =pagina;
	}