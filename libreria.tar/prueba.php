<?PHP
	echo 'Restriciones de ventas';
?>